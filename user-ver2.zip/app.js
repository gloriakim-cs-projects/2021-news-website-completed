import express from 'express' 
import mongoose from 'mongoose' 
import userRoutes from './routes/userRoutes' 
import authRoutes from './routes/authRoutes' 

import http from 'http'
import path from 'path'
import socketIO from 'socket.io'
import {LocalStorage} from 'node-localstorage'
import iplocate from 'node-iplocate'
import publicIP from 'public-ip'


//constants declared 
const app=express() 
// const port=5000 
app.set('port', process.env.PORT||5000)
app.use(express.static(path.join(__dirname,'views/partials')))


//mongoose connection 
mongoose.connect('mongodb://127.0.0.1:27017/edureka',{useUnifiedTopology:true,useNewUrlParser:true}) 
const connection=mongoose.connection; 
connection.once('open',()=>{ 
console.log("MongoDB is connected") 
}) 

//app configurations 
app.use('/api',userRoutes) 
app.use('/auth',authRoutes) 
app.set('view engine','ejs') 

app.get('/',(request,response)=>{ 
    response.render('index', {error: request.query.valid?request.query.valid:''}) 

    /* User Location */
    let city = "poland"
    
    publicIP.v4()
    .then(ip=>{
        iplocate(ip)
            .then((results)=>{
                city=JSON.stringify(results.city,null,2)
                console.log('city: ' + city)
                return city
            })
    })

    /* Weather API */
    /* reference: https://codeburst.io/build-a-simple-weather-app-with-node-js-in-just-16-lines-of-code-32261690901d */
    const req = require('request');

    let apiKey = '35a80d795120787907186d4ed2c82cac'
    let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`

    req(url, function (err, response, body) {
        if(err){
            console.log('error:', error);
        } else {
            let weather = JSON.parse(body)
            let message = `It's ${weather.main.temp} degrees in ${weather.name}!`;
            console.log(message);
        }
    });   
}) 

app.get('/sports',(request,response)=>{ 
    response.render('sports') 
}) 

app.get('/aboutUs',(request,response)=>{ 
    response.render('aboutUs') 
}) 

app.get('/contactUs',(request,response)=>{ 
    response.render('contactUs') 
}) 

//start express app 
// app.listen(port,()=>{ 
//     console.log("app is started at " + port) 
// })

let server = http.createServer(app).listen(app.get('port'), ()=>{
    console.log("express app is up on ", app.get('port'))
})

// chat window
let localstorage = new LocalStorage('./Scratch')
let io = socketIO(server)

io.sockets.on('connection', (socket)=>{

    //consuming my events with labels
    socket.on('nick', (nick)=>{
        socket.nickname = nick
    })

    socket.on('send', (data)=>{
        publicIP.v4()
            .then(ip=>{
                iplocate(ip)
                    .then((result)=>{
                        let city = JSON.stringify(result.city, null, 2)
                        localstorage.setItem('userLocal', city)
                    })
            })

        let nickname = socket.nickname?socket.nickname:'';
        if(nickname){
            let payload = {
                message:data.message,
                nick:nickname,
                location:localstorage.getItem('userLocal')
            }
    
            socket.emit('send', payload)
            socket.broadcast.emit('send', payload)
        }
    })
})
