import { Router, json, urlencoded } from 'express'; 
import cors from 'cors' 
import user from '../model/user' 
import news from '../model/news' 
import {LocalStorage} from 'node-localstorage' 
import jwt from 'jsonwebtoken' 
import config from '../config'; 
import alert from 'alert-node'

//defining constants 
const router = Router(); 
var corsOptions={ 
    origin:'*', 
    optionsSuccessStatus:200 
} 

router.route('/index').get((request, response) => { 
    response.render('index')

}); 

router.route('/register').get((request, response) => { 
    response.render('register')

}); 

router.route('/addNews').get((request, response) => { 
    /* login part */
    let localStorage= new LocalStorage('./Scratch') 
    let token=localStorage.getItem('authToken') 
    
    if(!token) 
        return response.redirect('/') 
    jwt.verify(token,config.secret,(err,decoded)=>{ 
        if(err) 
            response.redirect('/') 
        user.findById(decoded.id,{password:0},(err,user)=>{ 
            if(err) 
                response.redirect('/') 
            if(!user) 
                response.redirect('/') 
            if(user) {
                response.render('addNews',{ user })             
            }
        }) 
    }) 
});

//add news feed
router.route('/result').post(json(),urlencoded({extended:true}),cors(corsOptions), (request, response) => {
    
    // using mongoose model 
    news.create({
        title:request.body.title,
        description:request.body.description,
        url:request.body.url,
        urlImage:request.body.urlImage,
        date:request.body.date
      },(err,news)=>{
      if(err)
          return response.status(500).send('there was a problem in adding the news')
    //   response.send(' successfully added')
        alert('News was successfully added.')
        response.redirect('/api/newsList') 
    })
  });

router.route('/newsList').get((request, response) => { 
    news.find({}, function(err, news){
        if(err) {
          throw err
        } else {
            response.render('newsList',{"news": news}) 
            // console.log(news)
        }
    })

}); 

router.route('/newsList/edit/:title').get((request, response) => {
    
    news.findOne({ 'title': request.params.title }, (err, data) => {
        if (err) return handleError(err);
        // console.log('data: ' + data);
        response.render('updateNews', {"updateData": data}) 
      });  
  });

  
router.route('/update').post(json(),urlencoded({extended:true}),cors(corsOptions), (request, response) => {
    // using mongoose model 
    // news.findOneAndUpdate({ title: "123"}, {$set: { description: "hello"}}, {upsert: true}, function(err,doc) {
    //     if (err) { throw err; }
    //     else { console.log("Updated"); }
    //   });  
    console.log(request.body)
    news.findOneAndUpdate({
        title:request.body.title},{$set:
        {description:request.body.description,
        url:request.body.url,
        urlImage:request.body.urlImage,
        date:request.body.date}
      }
      ,(err,news)=>{
      if(err) throw err
      response.redirect('/api/newsList')
    //       return response.status(500).send('there was a problem in adding the news')
    //   response.send(' successfully added')
    //     alert('News was successfully added.')
    })
});


router.route('/newsList/delete/:title').get((request, response) => {

    // response.send('Congratulations!! you resolved a bug')
    console.log(request.params.title)
    //using mongoose model
    news.deleteOne({ title: request.params.title }, function (err) {
        if (err) return handleError(err);
        
        alert('News is successfully deleted.')
        response.redirect('/api/newsList') 
      });
  
  });


export default router;