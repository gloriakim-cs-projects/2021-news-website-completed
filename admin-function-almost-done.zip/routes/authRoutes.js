import { Router, json ,urlencoded} from 'express';
import cors from 'cors' 
import user from '../model/user' 
import news from '../model/news' 
import bcrypt from 'bcryptjs' 
import jwt from 'jsonwebtoken' 
import config from '../config' 
import {LocalStorage} from 'node-localstorage' 


//defining constants 
const router = Router(); 
var corsOptions={ 
    origin:'*', 
    optionsSuccessStatus:200 
} 

router.route('/register').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    let hashedPassword = bcrypt.hashSync(request.body.password,8) 

    //using mongoose model 
    user.create({ 
        name:request.body.name, 
        email:request.body.email, 
        password:hashedPassword 
    },(err,user)=>{ 
    if(err) 
        return response.status(500).send('found a problem in registering user') 
    //create token 
    let token= jwt.sign({id:user.id},config.secret,{expiresIn:86400}) 
    // response.send('successfully registered') 
    response.redirect('/api/addNews') 
    }) 
}); 

router.route('/login').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 
    //find from db if that user exists 
    user.findOne({name:request.body.name},(err,user)=>{ 
        if(err) 
            return response.status(500).send('found a problem in searching for user') 

        const validString= encodeURIComponent('!please enter a valid value') 
        if(!user) {
            response.redirect('/?valid=',validString) 
        }

        else{ 
            const passIsValid=bcrypt.compareSync(request.body.password,user.password) 
            if(!passIsValid) 
                return response.status(401).send({auth:false,token:null}) 
            let token = jwt.sign({id:user.id},config.secret,{expiresIn:86400}) 
            //return response.status(200).send({auth:true,token:token}) 
            //save the token in localstorage: 
            let localStorage=new LocalStorage('./Scratch') 
            localStorage.setItem('authToken',token)

            response.redirect('/api/addNews')

        }
    })

});

router.route('/newsList').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/newsList') 
}); 

export default router;