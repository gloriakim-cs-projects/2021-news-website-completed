import express from 'express' 
import mongoose from 'mongoose' 
import userRoutes from './routes/userRoutes' 
import authRoutes from './routes/authRoutes' 


//constants declared 
const app=express() 
const port=5000 

//mongoose connection 
mongoose.connect('mongodb://127.0.0.1:27017/edureka',{useUnifiedTopology:true,useNewUrlParser:true}) 
const connection=mongoose.connection; 
connection.once('open',()=>{ 
console.log("MongoDB is connected") 
}) 

//app configurations 
app.use('/api',userRoutes) 
app.use('/auth',authRoutes) 
app.set('view engine','ejs') 

app.get('/',(request,response)=>{ 
    response.render('index', {error: request.query.valid?request.query.valid:''}) 


    /* Weather API */
    let apiKey = 'f3d86be899c7c88b1bb5b8e8500812d3'
    let city = 'portland'
    let url = 'http://api.openweathermap.org/data/2.5/weather?q=portland&appid=f3d86be899c7c88b1bb5b8e8500812d3'
    // let url = `http://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}`
    // api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}

    const req = require('request');
    req(url, function (err, response, body) {
        if(err){
            console.log('error:', error);
        } else {
            console.log('body:', body);
        }
    });
}) 

app.get('/sports',(request,response)=>{ 
    response.render('sports') 
}) 

app.get('/aboutUs',(request,response)=>{ 
    response.render('aboutUs') 
}) 

app.get('/contactUs',(request,response)=>{ 
    response.render('contactUs') 
}) 

//start express app 
app.listen(port,()=>{ 
    console.log("app is started at " + port) 
})
