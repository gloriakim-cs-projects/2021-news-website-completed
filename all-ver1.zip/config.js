export default {
    'secret': 'supersecret'
}
