import mongoose from 'mongoose' 

//define my model 
var productSchema= mongoose.Schema({ 
    name: {type:String},
    price:{type:Number}
}, 
{ 
    collection:"products" 
}) 


export default mongoose.model('product', productSchema)