import { Router, json ,urlencoded} from 'express';
import cors from 'cors' 
import user from '../model/user' 
import product from '../model/product' 
import bcrypt from 'bcryptjs' 
import jwt from 'jsonwebtoken' 
import config from '../config' 
import {LocalStorage} from 'node-localstorage' 


//defining constants 
const router = Router(); 
var corsOptions={ 
    origin:'*', 
    optionsSuccessStatus:200 
} 

router.route('/user').get((_, response) => { 
    //using mongoose model 
    user.find((err,data)=>{ 
    if(err) 
        throw err 
    else 
        response.json(data) 
    }) 

}); 

router.route('/register').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    let hashedPassword = bcrypt.hashSync(request.body.password,8) 

    //using mongoose model 
    user.create({ 
        name:request.body.name, 
        email:request.body.email, 
        password:hashedPassword 
    },(err,user)=>{ 
    if(err) 
        return response.status(500).send('found a problem in registering user') 
    //create token 
    let token= jwt.sign({id:user.id},config.secret,{expiresIn:86400}) 
    response.send('successfully registered') 
    }) 
}); 




router.route('/login').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 
    //find from db if that user exists 
    user.findOne({name:request.body.name},(err,user)=>{ 
        if(err) 
            return response.status(500).send('found a problem in searching for user') 

        const validString= encodeURIComponent('!please enter a valid value') 
        if(!user) {
            response.redirect('/?valid=',validString) 
        }

        else{ 
            const passIsValid=bcrypt.compareSync(request.body.password,user.password) 
            if(!passIsValid) 
                return response.status(401).send({auth:false,token:null}) 
            let token = jwt.sign({id:user.id},config.secret,{expiresIn:86400}) 
            //return response.status(200).send({auth:true,token:token}) 
            //save the token in localstorage: 
            let localStorage=new LocalStorage('./Scratch') 
            localStorage.setItem('authToken',token) 
            if(user.role == 'Admin') {
                response.redirect('/api/adminProfile') 
            }
            else{
                response.redirect('/api/profile') 
            }

        }
    })

});


router.route('/verify').get( (request, response) => { 
    let token= request.headers['x-access-token'] 

    if(!token) 
        return response.status(401).send({auth:false,message:'No token provided'}) 

    jwt.verify(token,config.secret,(err,decoded)=>{ 
        if(err) 
            return response.status(500).send({auth:false,messgae:'wrong token'}) 
        user.findById(decoded.id,{password:0},(err,user)=>{ 
        if(err) 
            return response.status(500).send('problem in finding user') 
        if(!user) 
            return response.status(404).send('no user found') 

        return response.status(200).send(user) 
        }) 
    }) 

}); 


router.route('/shoppingList').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/shoppingList') 
}); 

router.route('/userList').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/userList')

}); 

router.route('/addUser').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/addUser') 
}); 

router.route('/addProduct').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/addProduct') 
}); 

router.route('/addU').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 
    let hashedPassword = bcrypt.hashSync(request.body.password,8) 

    user.create({ 
        type:request.body.type,
        name:request.body.name, 
        password:hashedPassword 
    },(err,user)=>{
        if(err) 
            return response.status(500).send('there was a problem in registering user') 
        //create token 
        let token= jwt.sign({id:user.id},config.secret,{expiresIn:86400}) 
        response.send('successfully registered') 
    }) 
}); 

router.route('/addP').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 
    //using mongoose model 
    product.create(request.body,(err,Product)=>{
        if(err) 
            return response.status(500).send('there was a problem in adding product') 
        
        response.send('Product was successfully added') 
    }) 
}); 

router.route('/toLogin').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/index') 
}); 

router.route('/toRegister').post(json(),urlencoded({extended:false}),cors(corsOptions), (request, response) => { 

    response.redirect('/api/register') 
}); 

export default router;