import { Router, json, urlencoded } from 'express'; 
import cors from 'cors' 
import user from '../model/user' 
import news from '../model/news' 
import {LocalStorage} from 'node-localstorage' 
import jwt from 'jsonwebtoken' 
import config from '../config'; 
import alert from 'alert-node'

//defining constants 
const router = Router(); 
var corsOptions={ 
    origin:'*', 
    optionsSuccessStatus:200 
} 

router.route('/addNews').get((request, response) => { 
    /* login part */
    let localStorage= new LocalStorage('./Scratch') 
    let token=localStorage.getItem('authToken') 
    
    if(!token) 
        return response.redirect('/') 
    jwt.verify(token,config.secret,(err,decoded)=>{ 
        if(err) 
            response.redirect('/') 
        user.findById(decoded.id,{password:0},(err,user)=>{ 
            if(err) 
                response.redirect('/') 
            if(!user) 
                response.redirect('/') 
            if(user) {
                response.render('addNews',{ user })                 
            }
        }) 

    }) 

});

//add news feed
router.route('/result').post(json(),urlencoded({extended:true}),cors(corsOptions), (request, response) => {
    
    // using mongoose model 
    news.create({
        title:request.body.title,
        description:request.body.description,
        url:request.body.url,
        urlImage:request.body.urlImage,
        date:request.body.date
      },(err,news)=>{
      if(err)
          return response.status(500).send('there was a problem in adding the news')
    //   response.send(' successfully added')
        alert('News was successfully added.')
        response.redirect('/api/newsList') 
    })
  });

router.route('/newsList').get((request, response) => { 
    news.find({}, function(err, news){
        if(err) {
          throw err
        } else {
            response.render('newsList',{"news": news}) 
            // console.log(news)
        }
    })

}); 

router.route('/index').get((request, response) => { 
    response.render('index')

}); 

router.route('/register').get((request, response) => { 
    response.render('register')

}); 

export default router;