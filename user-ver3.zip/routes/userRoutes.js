import { Router, json, urlencoded } from 'express'; 
import cors from 'cors' 
import user from '../model/user' 
import news from '../model/news' 
import {LocalStorage} from 'node-localstorage' 
import jwt from 'jsonwebtoken' 
import config from '../config'; 
import alert from 'alert-node'

//send email
const sgMail = require('@sendgrid/mail')
const sendGridAPI = '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';

//defining constants 
const router = Router(); 
var corsOptions={ 
    origin:'*', 
    optionsSuccessStatus:200 
} 

// router.route('/index').get((request, response) => { 
//     response.render('index')

// }); 

router.route('/register').get((request, response) => { 
    response.render('register')

}); 

router.route('/addNews').get((request, response) => { 
    
    //allow only authenticated users to access the pages
    const sourceFile = require('./authRoutes')
    var authenticated = sourceFile.authenticated

    /* login part */
    let localStorage= new LocalStorage('./Scratch') 
    let token=localStorage.getItem('authToken') 
        
    if(!token) 
        return response.redirect('/') 
    jwt.verify(token,config.secret,(err,decoded)=>{ 
        if(err) 
            response.redirect('/') 
        user.findById(decoded.id,{password:0},(err,user)=>{ 
            if(err) 
                response.redirect('/') 
            if(!user) 
                response.redirect('/') 
            if(user && authenticated == "true") {
                response.render('addNews',{ user })             
            }
            else {
                response.redirect('/') 
            }
        }) 
    }) 
});

//add news feed
router.route('/result').post(json(),urlencoded({extended:true}),cors(corsOptions), (request, response) => {
    
    // using mongoose model 
    news.create({
        title:request.body.title,
        description:request.body.description,
        url:request.body.url,
        urlImage:request.body.urlImage,
        date:request.body.date
      },(err,news)=>{
        if(err)
            return response.status(500).send('there was a problem in adding the news')
        alert('News was successfully added.')
        response.redirect('/api/newsList') 
    })
  });

router.route('/newsList').get((request, response) => { 
    //allow only authenticated users to access the pages
    const sourceFile = require('./authRoutes')
    var authenticated = sourceFile.authenticated
    if (authenticated == "true") {
        news.find({}, function(err, news){
            if(err) {
              throw err
            } else {
                let localStorage= new LocalStorage('./Scratch') 
                let token=localStorage.getItem('authToken') 
                
                if(!token) 
                    return response.redirect('/') 
                jwt.verify(token,config.secret,(err,decoded)=>{ 
                    if(err) 
                        response.redirect('/') 
                    user.findById(decoded.id,{password:0},(err,user)=>{ 
                        if(err) 
                            response.redirect('/') 
                        if(!user) 
                            response.redirect('/') 
                        if(user) {
                            response.render('newsList',{"news": news, user})             
                        }
                    }) 
                }) 
                // response.render('newsList',{"news": news}) 
                // console.log(news)
            }
        })
    }
    else {
    response.redirect('/') 
    }    
}); 

router.route('/newsList/edit/:title').get((request, response) => {
    
    news.findOne({ 'title': request.params.title }, (err, data) => {
        if (err) return handleError(err);
        response.render('updateNews', {"updateData": data}) 
      });  
  });

  
router.route('/update').post(json(),urlencoded({extended:true}),cors(corsOptions), (request, response) => {

    news.findOneAndUpdate({
        title:request.body.title},{$set:
        {description:request.body.description,
        url:request.body.url,
        urlImage:request.body.urlImage,
        date:request.body.date}
      }
      ,(err,news)=>{
      if(err) throw err
      response.redirect('/api/newsList')
    //       return response.status(500).send('there was a problem in adding the news')
    //   response.send(' successfully added')
    //     alert('News was successfully added.')
    })
});


router.route('/newsList/delete/:title').get((request, response) => {

    //using mongoose model
    news.deleteOne({ title: request.params.title }, function (err) {
        if (err) return handleError(err);
        
        alert('News is successfully deleted.')
        response.redirect('/api/newsList') 
      });
  
  });

  router.route('/sendEmail').post(json(),urlencoded({extended:true}),cors(corsOptions), (request, response) => {
    sgMail.setApiKey(sendGridAPI)
    console.log(request.body.description)
    console.log(request.body.email)
    let email = request.body.email;
    let description = request.body.description;
    const msg = {
        to: email, // Change to your recipient
        from: 'chowdhurymdabdulla@gmail.com', // Change to your verified sender
        subject: 'Sending with SendGrid is Fun',
        text: description,
        html: description,
    }
    
    sgMail
        .send(msg)
        .then(() => {
            console.log('email has send succesfully');
            alert('Email sent successfully');
            response.redirect('/') 
        })
        .catch(error => {
        // Log friendly error
        console.error(error);
    
        if (error.response) {
            // Extract error msg
            const {message, code, response} = error;
    
            // Extract response msg
            const {headers, body} = response;
    
            console.error(body);
        }
        });
  });

export default router;